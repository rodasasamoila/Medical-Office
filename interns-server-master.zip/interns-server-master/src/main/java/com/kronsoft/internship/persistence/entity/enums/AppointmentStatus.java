package com.kronsoft.internship.persistence.entity.enums;

public enum AppointmentStatus {
	CREATED, PLANNED, CONFIRMED, CLOSED, CANCELED
}
