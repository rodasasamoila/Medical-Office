package com.kronsoft.internship.persistence.entity.enums;

public enum PatientSex {
	MALE, FEMALE, UNDEFINED
}
