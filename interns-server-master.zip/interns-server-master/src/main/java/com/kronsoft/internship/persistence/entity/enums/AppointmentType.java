package com.kronsoft.internship.persistence.entity.enums;

public enum AppointmentType {
	REGULAR, HOLIDAY, VACATION, GROUP
}
